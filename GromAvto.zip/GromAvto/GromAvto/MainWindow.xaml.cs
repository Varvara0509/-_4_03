﻿using GromAvto.Classes;
using GromAvto.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace GromAvto
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn_enter_Click(object sender, RoutedEventArgs e)
        {

            string login = tb_login.Text.Trim();
            string password = tb_password.Text.Trim();

            // Ищем пользователя с такими логином и паролем (более эффективно через БД)
            var user = DB.Context.Пользователи.FirstOrDefault(u => u.Логин == login && u.Пароль == password);

            if (user != null)
            {
                MessageBox.Show($"Добро пожаловать\nВаша роль: {user.Роль_сотрудника}", "Уведомление", MessageBoxButton.OK, MessageBoxImage.Information);
                Products productsWindow = new Products(user);
                productsWindow.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("Данные не найдены", "Ошибка входа", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void btnGuest_Click(object sender, RoutedEventArgs e)
        {
            auth("Гость", "Гость");
        }

        private void auth(string login, string password)
        {
            if (login == "Гость" && password == "Гость")
            {
                // Создаём полноценный объект для гостя
                var guestUser = new Пользователи
                {
                    Логин = "Гость",
                    Роль_сотрудника = "Гость"
                };

                Products window = new Products(guestUser);
                window.Show();
                this.Close();
                return;
            }


        }
    }
}


