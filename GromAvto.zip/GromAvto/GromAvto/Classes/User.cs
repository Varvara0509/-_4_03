﻿using GromAvto.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GromAvto.Classes
{
    internal class User
    {
        public static Пользователи lastUser;

        public static Пользователи getUser(string login, string password)
        {
            lastUser = DB.Context.Пользователи.Where(u => u.Логин == login && u.Пароль == password).FirstOrDefault();
            return lastUser;
        }
    }
}
