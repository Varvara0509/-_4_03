﻿using GromAvto.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GromAvto.Classes
{
    internal class DB
    {
        public static Гром02_03Entities1 Context { get; } = new Гром02_03Entities1();
        public DB() { }
    }
}
