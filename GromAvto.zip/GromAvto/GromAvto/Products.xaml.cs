﻿using GromAvto.Classes;
using GromAvto.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace GromAvto
{
    /// <summary>
    /// Логика взаимодействия для Products.xaml
    /// </summary>
    public partial class Products : Window
    {
        private Пользователи currentUser;
        public Products(Пользователи user)
        {
            InitializeComponent();
            currentUser = user;
            ConfigureInterfaceByRole();
        }
        private void ConfigureInterfaceByRole()
        {
            // Отображаем текущего пользователя
            if (currentUser != null)
            {
                lblTitle.Text = $"Текущий пользователь: {currentUser.ФИО} - {currentUser.Роль_сотрудника}";
            }

            // Настраиваем интерфейс в зависимости от роли
            if (currentUser?.Роль_сотрудника == "Администратор")
            {
                // Админ видит всё: фильтры, сортировку, поиск и кнопки редактирования
                panelFilter.Visibility = Visibility.Visible;
                panelAdmin.Visibility = Visibility.Visible;
                btnOrders.IsEnabled = true;
            }
            else if (currentUser?.Роль_сотрудника == "Менеджер")
            {
                // Менеджер видит фильтры, сортировку, поиск, но без редактирования
                panelFilter.Visibility = Visibility.Visible;
                panelAdmin.Visibility = Visibility.Collapsed;
                btnOrders.IsEnabled = true;
            }
            else if (currentUser?.Роль_сотрудника == "Клиент" || currentUser?.Роль_сотрудника == "Гость")
            {
                // Клиент и гость видят только просмотр товаров
                panelFilter.Visibility = Visibility.Collapsed;
                panelAdmin.Visibility = Visibility.Collapsed;
                btnOrders.IsEnabled = false;

                if (currentUser?.Роль_сотрудника == "Гость")
                {
                    lblStatus.Text = "Гостевой режим - только просмотр";
                }
            }
        }

        private void btn_changeUser(object sender, RoutedEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show(
                "Вы действительно хотите сменить пользователя?",
                "Подтверждение",
                MessageBoxButton.YesNo,
                MessageBoxImage.Question);

            if (result == MessageBoxResult.Yes)
            {
                // Создаём новое окно входа
                MainWindow loginWindow = new MainWindow();
                loginWindow.Show();

                // Закрываем текущее окно
                this.Close();
            }
        }

        private void btnOrders_Click(object sender, RoutedEventArgs e)
        {
            //Orders ordersWindow = new Orders(currentUser);
            //ordersWindow.Show();
            //this.Close();
        }

        private void btnProducts_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
